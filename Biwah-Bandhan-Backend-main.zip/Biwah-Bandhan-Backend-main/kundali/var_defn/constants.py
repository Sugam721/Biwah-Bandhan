

#Housenumber related constants
TAN = 1
DHAN = 2
ANUJ = 3
MAATA = 4
SANTAAN = 5
ROG = 6
YUVATI = 7
AAYU = 8
BHAGYA = 9
KARMA = 10
LAABA = 11
KARCH = 12

